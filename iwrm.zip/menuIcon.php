<?
	if($groupRow['id']==56)
		echo "icon-home";
	else if($groupRow['id']==1)
		echo "icon-user";
	else if($groupRow['id']==795)
		echo "icon-phone";
	else if($groupRow['id']==1009)
		echo "icon-book";
	else if($groupRow['id']==994)
		echo "icon-user-md";
	else if($groupRow['id']==995)
		echo "icon-group";
	else if($groupRow['id']==796)
		echo "icon-star";
	else if($groupRow['id']==1022)
		echo "icon-link";
	else if($groupRow['id']==997)
		echo "icon-user";
	else if($groupRow['id']==234)
		echo "icon-envelope-alt";
	else if($groupRow['id']==1159)
		echo "icon-comments";
?>