<?php
$groups->writeBreadCrumb($pageId);
?>